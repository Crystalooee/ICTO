package com.chefood.biz.user.vo;

import java.sql.Date;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@XmlRootElement
public class UserVO {
	// accpet 추가
	private String user_id;
	private String password;
	private String user_name;
	private String user_address;
	private int user_gender;
	private Date user_birthdate;
	private String user_phone;
	
	private int accept;
	
	public int getAccept() {
		return accept;
	}
	public void setAccept(int accept) {
		this.accept = accept;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	public int getUser_gender() {
		return user_gender;
	}
	public void setUser_gender(int user_gender) {
		this.user_gender = user_gender;
	}
	public Date getUser_birthdate() {
		return user_birthdate;
	}
	public void setUser_birthdate(Date user_birthdate) {
		this.user_birthdate = user_birthdate;
	}
	public String getUser_phone() {
		return user_phone;
	}
	public void setUser_phone(String user_phone) {
		this.user_phone = user_phone;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserVO [user_id=");
		builder.append(user_id);
		builder.append(", password=");
		builder.append(password);
		builder.append(", user_name=");
		builder.append(user_name);
		builder.append(", user_address=");
		builder.append(user_address);
		builder.append(", user_gender=");
		builder.append(user_gender);
		builder.append(", user_birthdate=");
		builder.append(user_birthdate);
		builder.append(", user_phone=");
		builder.append(user_phone);
		builder.append(", accept=");
		builder.append(accept);
		builder.append("]");
		return builder.toString();
	}
}
