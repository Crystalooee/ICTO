package com.chefood.biz.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chefood.biz.user.dao.IUserDAO;
import com.chefood.biz.user.vo.UserVO;

@Service
public class UserService implements IUserService{

	@Autowired
	private IUserDAO dao;
	@Override
	public UserVO login(UserVO vo) {
		return dao.selectUserID(vo);
	}
	@Override
	public boolean registerUser(UserVO vo) {
		return dao.insertUserInfo(vo);
	}
	
}
