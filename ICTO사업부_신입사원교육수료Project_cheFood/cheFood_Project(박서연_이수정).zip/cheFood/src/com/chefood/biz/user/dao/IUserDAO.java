package com.chefood.biz.user.dao;

import com.chefood.biz.user.vo.UserVO;

public interface IUserDAO {
	public UserVO selectUserID(UserVO vo);

	public boolean insertUserInfo(UserVO vo);
}
