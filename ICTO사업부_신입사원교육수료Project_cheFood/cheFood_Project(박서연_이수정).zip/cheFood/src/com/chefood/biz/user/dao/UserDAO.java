package com.chefood.biz.user.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.chefood.biz.user.vo.UserVO;

@Repository
public class UserDAO implements IUserDAO{
	
	@Autowired
	private SqlSession sqlSession;
	
	public UserVO selectUserID(UserVO vo){
		return sqlSession.selectOne("selectUserID", vo);
	}

	@Override
	public boolean insertUserInfo(UserVO vo) {
		return sqlSession.insert("insertUserInfo", vo)>0?true:false;
	}
}
