package com.chefood.biz.party.service;

import java.util.ArrayList;

import com.chefood.biz.party.vo.PartyVO;
import com.chefood.biz.party.vo.Party_registerVO;
import com.chefood.biz.user.vo.UserVO;

public interface IPartyService {

	ArrayList<PartyVO> getPartyLatLng(String term);

	ArrayList<PartyVO> getPartyList(UserVO vo);

	ArrayList<UserVO> getPartyParticipant(PartyVO vo);

	boolean acceptParticipant(Party_registerVO regiVO);

	boolean denyParticipant(Party_registerVO regiVO);

	PartyVO getPartyInfo(Party_registerVO regiVO);
	
	Party_registerVO getRegisterInfo(Party_registerVO regiVO);

	boolean participate(PartyVO vo);

	boolean cancelParticipate(PartyVO vo);

	boolean registerParty(PartyVO vo);


}
