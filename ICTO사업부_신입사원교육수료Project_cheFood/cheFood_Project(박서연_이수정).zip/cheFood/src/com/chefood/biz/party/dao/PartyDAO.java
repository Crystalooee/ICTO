package com.chefood.biz.party.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.chefood.biz.party.vo.PartyVO;
import com.chefood.biz.party.vo.Party_registerVO;
import com.chefood.biz.user.vo.UserVO;
/**
 * 
 * @author student
 * PartyDAO
 * Party 테이블과 관련된 로직을 처리하는 DAO
 */
@Repository
public class PartyDAO implements IPartyDAO{
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public ArrayList<PartyVO> selectPartyLatLng(String term) {
		HashMap<String, String> map = new HashMap<>();
		map.put("term", term);
		return (ArrayList)sqlSession.selectList("selectPartyLatLng", map);
	}

	@Override
	public ArrayList<PartyVO> selectPartyList(UserVO vo) {
		return (ArrayList)sqlSession.selectList("selectPartyList", vo);
	}

	@Override
	public ArrayList<UserVO> selectPartyParticipant(PartyVO vo) {
		// 파티 신청자 조회
		// table: party_register, users 조인
		// param: party_seq, result: user_id, user_name, user_birthdate, accept
		return (ArrayList)sqlSession.selectList("selectPartyParticipant", vo);
	}

	@Override
	public boolean updateAcceptParticipant(Party_registerVO vo) {
		// 파티 신청자의 신청 수락
		// table: party_register
		// param: applicant_id, party_seq
		vo.setAccept(2);
		return sqlSession.update("updateAcceptParticipant", vo)>0?true:false;
	}

	@Override
	public boolean updateDenyParticipant(Party_registerVO vo) {
		// 파티 신청자의 신청 거절
		// table: party_register
		// param: applicant_id, party_seq
		vo.setAccept(3);
		return sqlSession.update("updateAcceptParticipant", vo)>0?true:false;
	}

	@Override
	public PartyVO selectPartyInfo(Party_registerVO vo) {
		// 지도
		// 클릭 시 ajax
		// getPartyInfo.do
		// 파티 정보 가져오기. party_register에서 내가 신청한 파티인지 확인하여 0이면 신청 전, accept가 1이면 신청중, 2이면 수락, 3이면 거절된 파티
		// table: party , party_register
		// param: party_seq, applicant_id result: id, address, menu, time, max, now, accept 조회
		return sqlSession.selectOne("selectPartyInfo", vo);
	}
	
	@Override
	public Party_registerVO selectRegisterInfo(Party_registerVO vo){
		return sqlSession.selectOne("selectRegisterInfo", vo);
	}

	@Override
	public int selectMaxPeople(PartyVO vo) {
		return sqlSession.selectOne("selectMaxPeople", vo);
	}

	@Override
	public int selectNowPeople(PartyVO vo) {
		return sqlSession.selectOne("selectNowPeople", vo);
	}
	
	@Override
	public boolean insertParticipateInfo(PartyVO vo) {
		// 신청/취소
		// participate.do
		// cancelParticipate.do
		// 3. 그렇지 않으면 party_seq, user_id을 register 테이블에 삽입하고
		return sqlSession.insert("insertParticipateInfo", vo)>0?true:false;
	}

	@Override
	public void updateNowPeople(PartyVO vo) {
		// 3. party 테이블에서 nowPeople을 업데이트
		sqlSession.update("updateNowPeople", vo);
	}

	@Override
	public boolean deleteParticipateInfo(PartyVO vo) {
		// delete table: party_register
		// 1. param: party_seq, user_id을 register 테이블에서 삭제
		return sqlSession.delete("deleteParticipateInfo", vo)>0?true:false;
	}

	@Override
	public boolean insertNewParty(PartyVO vo) {
		// registerParty.jsp 에서 새 파티 등록하기
		return sqlSession.insert("insertNewParty", vo)>0?true:false;
	}
	
}

