package com.chefood.biz.party.vo;

import javax.xml.bind.annotation.XmlRootElement;
/**
 * 
 * @author student
 * PartyVO
 */
@XmlRootElement
public class PartyVO{
	private int party_seq;
	private String chef_id;
	private String party_address;
	private double party_lat;
	private double party_lng;
	private String party_menu;
	private String party_time;
	private int party_maxPeople;
	private int party_nowPeople;
	public int getParty_seq() {
		return party_seq;
	}
	public void setParty_seq(int party_seq) {
		this.party_seq = party_seq;
	}
	public String getChef_id() {
		return chef_id;
	}
	public void setChef_id(String chef_id) {
		this.chef_id = chef_id;
	}
	public String getParty_address() {
		return party_address;
	}
	public void setParty_address(String party_address) {
		this.party_address = party_address;
	}
	public double getParty_lat() {
		return party_lat;
	}
	public void setParty_lat(double party_lat) {
		this.party_lat = party_lat;
	}
	public double getParty_lng() {
		return party_lng;
	}
	public void setParty_lng(double party_lng) {
		this.party_lng = party_lng;
	}
	public String getParty_menu() {
		return party_menu;
	}
	public void setParty_menu(String party_menu) {
		this.party_menu = party_menu;
	}
	public String getParty_time() {
		return party_time;
	}
	public void setParty_time(String party_time) {
		this.party_time = party_time;
	}
	public int getParty_maxPeople() {
		return party_maxPeople;
	}
	public void setParty_maxPeople(int party_maxPeople) {
		this.party_maxPeople = party_maxPeople;
	}
	public int getParty_nowPeople() {
		return party_nowPeople;
	}
	public void setParty_nowPeople(int party_nowPeople) {
		this.party_nowPeople = party_nowPeople;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PartyVO [party_seq=");
		builder.append(party_seq);
		builder.append(", chef_id=");
		builder.append(chef_id);
		builder.append(", party_address=");
		builder.append(party_address);
		builder.append(", party_lat=");
		builder.append(party_lat);
		builder.append(", party_lng=");
		builder.append(party_lng);
		builder.append(", party_menu=");
		builder.append(party_menu);
		builder.append(", party_time=");
		builder.append(party_time);
		builder.append(", party_maxPeople=");
		builder.append(party_maxPeople);
		builder.append(", party_nowPeople=");
		builder.append(party_nowPeople);
		builder.append("]");
		return builder.toString();
	}
	
}
