package com.chefood.biz.party.dao;

import java.util.ArrayList;

import com.chefood.biz.party.vo.PartyVO;
import com.chefood.biz.party.vo.Party_registerVO;
import com.chefood.biz.user.vo.UserVO;

public interface IPartyDAO {

	ArrayList<PartyVO> selectPartyLatLng(String term);

	ArrayList<PartyVO> selectPartyList(UserVO vo);

	ArrayList<UserVO> selectPartyParticipant(PartyVO vo);

	boolean updateAcceptParticipant(Party_registerVO vo);

	boolean updateDenyParticipant(Party_registerVO vo);

	PartyVO selectPartyInfo(Party_registerVO vo);

	Party_registerVO selectRegisterInfo(Party_registerVO vo);

	int selectMaxPeople(PartyVO vo);

	int selectNowPeople(PartyVO vo);

	boolean insertParticipateInfo(PartyVO vo);

	void updateNowPeople(PartyVO vo);

	boolean deleteParticipateInfo(PartyVO vo);

	boolean insertNewParty(PartyVO vo);

}
