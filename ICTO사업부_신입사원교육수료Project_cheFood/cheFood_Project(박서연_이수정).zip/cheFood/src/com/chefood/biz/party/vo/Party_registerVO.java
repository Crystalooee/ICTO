package com.chefood.biz.party.vo;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@XmlRootElement
public class Party_registerVO {
	private String applicant_id;
	private int party_seq;
	private int accept;
	public String getApplicant_id() {
		return applicant_id;
	}
	public void setApplicant_id(String applicant_id) {
		this.applicant_id = applicant_id;
	}
	public int getParty_seq() {
		return party_seq;
	}
	public void setParty_seq(int party_seq) {
		this.party_seq = party_seq;
	}
	public int getAccept() {
		return accept;
	}
	public void setAccept(int accept) {
		this.accept = accept;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Party_register [applicant_id=");
		builder.append(applicant_id);
		builder.append(", party_seq=");
		builder.append(party_seq);
		builder.append(", accept=");
		builder.append(accept);
		builder.append("]");
		return builder.toString();
	}
}
