package com.chefood.biz.party.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.chefood.biz.party.dao.IPartyDAO;
import com.chefood.biz.party.vo.PartyVO;
import com.chefood.biz.party.vo.Party_registerVO;
import com.chefood.biz.user.vo.UserVO;

@Service
public class PartyService implements IPartyService{
	@Autowired
	private IPartyDAO partyDao;
	
	@Override
	public ArrayList<PartyVO> getPartyLatLng(String term) {
		return partyDao.selectPartyLatLng(term);
	}

	@Override
	public ArrayList<PartyVO> getPartyList(UserVO vo) {
		return partyDao.selectPartyList(vo);
	}

	@Override
	public ArrayList<UserVO> getPartyParticipant(PartyVO vo) {
		return partyDao.selectPartyParticipant(vo);
	}

	@Override
	public boolean acceptParticipant(Party_registerVO vo) {
		return partyDao.updateAcceptParticipant(vo);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public boolean denyParticipant(Party_registerVO vo) {
		PartyVO ptVo = new PartyVO();
		ptVo.setParty_seq(vo.getParty_seq());
		int now = partyDao.selectNowPeople(ptVo);
		ptVo.setParty_nowPeople(now-1);
		partyDao.updateNowPeople(ptVo);
		return partyDao.updateDenyParticipant(vo);
	}

	@Override
	public PartyVO getPartyInfo(Party_registerVO vo) {
		return partyDao.selectPartyInfo(vo);
	}
	
	@Override
	public	Party_registerVO getRegisterInfo(Party_registerVO regiVO){
		return partyDao.selectRegisterInfo(regiVO);
	}


	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public boolean participate(PartyVO vo) {
		int max = partyDao.selectMaxPeople(vo);
		int now = partyDao.selectNowPeople(vo);
		boolean done = false;
		if(now>=max){
			return done;
		}else{
			done = partyDao.insertParticipateInfo(vo);
			// party_seq로 조회. nowPeople을 ++1
			vo.setParty_nowPeople(now+1);
			partyDao.updateNowPeople(vo);
			return done;
		}
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public boolean cancelParticipate(PartyVO vo) {
		// 현재 인원 조회
		int now = partyDao.selectNowPeople(vo);
		boolean done = false;
		done = partyDao.deleteParticipateInfo(vo);
		vo.setParty_nowPeople(now-1);
		partyDao.updateNowPeople(vo);
		// TODO Auto-generated method stub
		return done;
	}

	@Override
	public boolean registerParty(PartyVO vo) {
		return partyDao.insertNewParty(vo);
	}

}
