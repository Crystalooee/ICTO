$(function(){
	// 지도 가져오기
	// 지도 뿌려지면서 DB의 마커 좌표, 상품 가져오기
	// 
	var latitude = 0;
	var longitude = 0;
	function getLocation(){
		if(navigator.geolocation){
			console.log('위치 추적 중');
			navigator.geolocation.getCurrentPosition(showPosition, showError);
		}else{
			alert('위치를 찾을 수 없음');
		}
	}
	function showPosition(position){
		latitude = position.coords.latitude;
		longitude = position.coords.longitude;
	}
	//위치 추적 Failure
	function showError(error){
	     switch (error.code){
	          case error.PERMISSION_DENIED:
	               alert('User denied the request for Geolocation.');
	               break;
	          case error.POSITION_UNAVAILABLE:
	               alert('Location information is unavailable.');
	               break;
	          case error.TIMEOUT:
	               alert('The request to get user location timed out.');
	               break;
	          case error.UNKNOWN_ERROR:
	               alert('An unknown error occurred.');
	               break;
	     }
	}
	getLocation();
	console.log(latitude+" , "+longitude);
	if(latitude==0){
		latitude=37.5675451;
	}
	if(longitude==0){
		longitude=126.9773356;
	}
		var oSeoulCityPoint = new nhn.api.map.LatLng(latitude, longitude);
		var defaultLevel = 11;
		var oMap = new nhn.api.map.Map(document.getElementById('map'), {
										// 처음 맵 로딩 시 좌표
		                                point : oSeoulCityPoint,
		                                // 처음 맵 로딩 시 줌되어있는 level : 11
		                                zoom : defaultLevel,
		                                // 마우스 줌으로 지도 이동 true
		                                enableWheelZoom : true,
		                                // 드래그해서 지도 이동 true
		                                enableDragPan : true,
		                                enableDblClickZoom : false,
		                                mapMode : 0,
		                                activateTrafficMap : false,
		                                activateBicycleMap : false,
		                                minMaxLevel : [ 1, 14 ],
		                                size : new nhn.api.map.Size(800, 480),
										detectCoveredMarker : true
		});
		// 줌 슬라이더
		var oSlider = new nhn.api.map.ZoomControl();
		oMap.addControl(oSlider);
		oSlider.setPosition({
		        top : 10,
		        right : 10
		});
		
		// 맵 타입 버튼
		var oMapTypeBtn = new nhn.api.map.MapTypeBtn();
		oMap.addControl(oMapTypeBtn);
		oMapTypeBtn.setPosition({
		        bottom : 30,
		        right : 20
		});
		// 마커 사이즈
		var jSize = new nhn.api.map.Size(32, 37);
		var oSize = new nhn.api.map.Size(35, 42);
		// 클릭했을 때 딱 클릭한 곳에 마커 생기기 : 14, 37
		var oOffset = new nhn.api.map.Size(14, 37);
		// 재료 아이콘
		var jIcon = new nhn.api.map.Icon('http://imgur.com/ry6yLC6.png', jSize, oOffset);
		// 요리 아이콘
		var oIcon = new nhn.api.map.Icon('http://i.imgur.com/UuSgZsb.png', oSize, oOffset);
		
		var oInfoWnd = new nhn.api.map.InfoWindow();
		oInfoWnd.setVisible(false);
		oMap.addOverlay(oInfoWnd);
		
		oInfoWnd.setPosition({
		        top : 20,
		        left :20
		});
		
		var oLabel = new nhn.api.map.MarkerLabel(); // - 마커 라벨 선언.
		oMap.addOverlay(oLabel); // - 마커 라벨 지도에 추가. 기본은 라벨이 보이지 않는 상태로 추가됨.
		
		oInfoWnd.attach('changeVisible', function(oCustomEvent) {
		        if (oCustomEvent.visible) {
		                oLabel.setVisible(false);
		        }
		});
		
		oMap.attach('mouseenter', function(oCustomEvent) {
		
		        var oTarget = oCustomEvent.target;
		        // 마커위에 마우스 올라간거면
		        if (oTarget instanceof nhn.api.map.Marker) {
		                var oMarker = oTarget;
		                // 라벨을 보여줘라
		                oLabel.setVisible(true, oMarker); // - 특정 마커를 지정하여 해당 마커의 title을 보여준다.
		        }
		});
		
		oMap.attach('mouseleave', function(oCustomEvent) {
		        var oTarget = oCustomEvent.target;
		        // 마커위에서 마우스 나간거면
		        if (oTarget instanceof nhn.api.map.Marker) {
		                oLabel.setVisible(false);
		        }
		});
		
		// 클릭하면 아무 효과 없음. 마커일 때만 ajax로 가져오기
		// 클릭하면 마커 생성됨
		var ps = '';
		oMap.attach('click', function(oCustomEvent) {
				// 클릭한 포인트
		        var oPoint = oCustomEvent.point;
				console.log(oPoint.toString());
		        var oTarget = oCustomEvent.target;
		        console.log(oTarget.toString());
		        oInfoWnd.setVisible(false);
		        // 마커 클릭하면
		        if (oTarget instanceof nhn.api.map.Marker) {
		                // 겹침 마커 클릭한거면
		                if (oCustomEvent.clickCoveredMarker) {
		                        return;
		                }
		                // 마커에 대한 info창 보여주기
		                ps = oTarget.getTitle().substr(0, oTarget.getTitle().lastIndexOf('.'));
		                $.ajax({
		                	url: 'getPartyInfo.do',
		                	type: 'get',
		                	data:{
		                		party_seq: ps
		                	},
		                	success: function(data){
		                		console.log(data);
		                		if(data.chef_id=='none'){
		                			alert("로그인 후 조회 가능합니다");
		                			location.href="index.jsp";
		                			return;
		                		}
				                $('#exampleModal').modal('show');
				                $('#getChefId').text(data.chef_id);
				                $('#getPartyTime').text(data.party_time);
				                $('#getPartyAddress').text(data.party_address);
				                $('#getPartyMenu').text(data.party_menu);
				                $('#getPartyPeople').text("신청 "+data.party_nowPeople+"명 / 최대"+data.party_maxPeople+"명");
		                	},
		                	error: function(data){
		                		console.log('에러');
		                		console.log(data);
		                		return;
		                	}
		                	
		                });
		                // 신청한 건지 아닌지 가져오기
	                	$.ajax({
	                		url: 'getRegisterInfo.do',
	                		type: 'get',
	                		data:{
		                		party_seq: ps
		                	},
	                		success:function(data){
	                			if(data==''){
	                				// 아무것도 없으면 아직 신청 안함
	                				$('#statusDiv').show();
	                				$('#participateBtn').show();
	                				$('#cancelParticipateBtn').hide();
	                				$('#registered').hide();
	                				$('#denied').hide();
	                			}else if(data.accept=='1'){
	                				// 1이면 신청한 상태
	                				$('#statusDiv').show();
	                				$('#participateBtn').hide();
	                				$('#cancelParticipateBtn').show();
	                				$('#registered').text('신청한 상태입니다').show();
	                				$('#denied').hide();
	                			}else if(data.accept=='2'){
	                				// 2이면 수락됨
	                				$('#statusDiv').show();
	                				$('#participateBtn').hide();
	                				$('#cancelParticipateBtn').show();
	                				$('#registered').text('신청이 수락되었습니다').show();
	                				$('#denied').hide();
	                			}else if(data.accept=='3'){
	                				// 3이면 거절한 상태
	                				$('#statusDiv').show();
	                				$('#participateBtn').hide();
	                				$('#cancelParticipateBtn').hide();
	                				$('#registered').hide();
	                				$('#denied').show();
	                			}else{
	                				// 자기 자신의 모임이면 숨기기
	                				$('#statusDiv').hide();
	                			}
	                		}
	                	});
		        }
		});
		
		$('#participateBtn').click(function(){
			$.ajax({
				url:'participate.do',
				type:'get',
				data:{
					party_seq : ps
				},
				success:function(data){
					alert('신청 완료');
					$('#exampleModal').modal('hide');
				},
				error:function(data){
					alert("신청 중 에러 발생");
				}
			});
		});
		
		$('#cancelParticipateBtn').click(function(){
			$.ajax({
				url:'cancelParticipate.do',
				type:'get',
				data:{
					party_seq : ps
				},
				success:function(data){
					alert("신청 취소 완료");
					$('#exampleModal').modal('hide');
				},
				error:function(data){
					alert('신청 취소 중 에러 발생');
				}
			});
		});
		
		var markerGroup = new nhn.api.map.GroupOverlay();
		
		// 마커 포인트 가져오기
		$.ajax({
			url: 'getMarkers.do',
			type: 'post',
			dataType: 'json',
			data: {
				term : '9999-12-31 23:59'
			},
			success: function(data){
				for(var i = 0; i<data.length; i++){
					var seq = data[i].party_seq;
					var chef = data[i].chef_id;
					var nowLat = data[i].party_lat;
					var nowLng = data[i].party_lng;
					var oPoint = new nhn.api.map.LatLng(nowLng, nowLat);
					var nowMenu = data[i].party_menu;
					var nowTime = data[i].party_time;
					var oMarker = '';
					if(chef=='mine'){
						 oMarker= new nhn.api.map.Marker(jIcon, { title : seq+'. 메뉴 : ' + nowMenu + " ( "+nowTime+" ) "});
					}else{
						 oMarker= new nhn.api.map.Marker(oIcon, { title : seq+'. 메뉴 : ' + nowMenu + " ( "+nowTime+" ) "});
					}
					oMarker.setPoint(oPoint);
					oMap.addOverlay(oMarker);
				}
			},
			error: function(data){
				alert('모임 데이터를 읽는 데에 실패했습니다');
				console.log(data);
			}
		});
		
		// 기간별 조회
		$('.term').on('click', function(){
			term = $(this).attr('title');
			
			oMap.clearOverlay();
			
			var today = new Date();
			var findDate = '';
			if(term==1){
				findDate = new Date(today.getFullYear(), today.getMonth(), today.getDate()+1, today.getHours(), today.getMinutes());
			}else if(term==7){
				findDate = new Date(today.getFullYear(), today.getMonth(), today.getDate()+7, today.getHours(), today.getMinutes());
			}else if(term==30){
				findDate = new Date(today.getFullYear(), today.getMonth(), today.getDate()+30, today.getHours(), today.getMinutes());
			}else{
				findDate = new Date(9999, 11, 31, 23, 59);
			}
			var newDate = findDate.getFullYear()+'-'+(findDate.getMonth()+1)+'-'+findDate.getDate()+' '+findDate.getHours()+':'+findDate.getMinutes();
			$.ajax({
				url: 'getMarkers.do',
				type: 'post',
				dataType: 'json',
				data: {
					term: newDate
				},
				success: function(data){
					for(var i = 0; i<data.length; i++){
						var seq = data[i].party_seq;
						var chef = data[i].chef_id;
						var nowLat = data[i].party_lat;
						var nowLng = data[i].party_lng;
						var oPoint = new nhn.api.map.LatLng(nowLng, nowLat);
						var nowMenu = data[i].party_menu;
						var nowTime = data[i].party_time;
						var oMarker = '';
						if(chef=='mine'){
							oMarker= new nhn.api.map.Marker(jIcon, { title : seq+'. 메뉴 : ' + nowMenu + " ( "+nowTime+" ) "});
						}else{
							oMarker= new nhn.api.map.Marker(oIcon, { title : seq+'. 메뉴 : ' + nowMenu + " ( "+nowTime+" ) "});
						}
						oMarker.setPoint(oPoint);
						oMap.addOverlay(oMarker);
					}
				},
				error: function(data){
					alert('모임 데이터를 읽는 데에 실패했습니다');
					console.log(data);
				}
			});
		});
});